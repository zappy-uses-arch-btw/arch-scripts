# 🎨 Ultimate BSPWM + Wallust Rice Setup

**Complete automated setup for Arch Linux with dynamic color schemes**

A one-script solution that installs and configures everything you need for a beautiful, fully themed bspwm environment. Just run it and go!

## 📦 What You Get

### Window Manager & Desktop
- **bspwm** - Tiling window manager
- **sxhkd** - Hotkey daemon
- **picom** - Compositor with blur and rounded corners
- **polybar** - Beautiful centered status bar
- **rofi** - App launcher with matching theme
- **dunst** - Notification daemon

### Dynamic Theming
- **wallust** - Automatic color scheme generation from wallpapers
- All apps themed to match your wallpaper
- Instant color updates across entire system

### Applications
- **alacritty** - GPU-accelerated terminal
- **tmux** - Terminal multiplexer
- **yazi** - Modern file manager (TUI)
- **neovim** - Minimal but powerful config

### Wallpaper Management
- **cwal** - Simple command to change everything at once
- Rofi selector for easy browsing
- Visual thumbnail picker
- Random wallpaper support

## 🚀 Quick Start

### Step 1: Download and Run

```bash
# Download the ultimate setup script
chmod +x ultimate_setup.sh

# Run it!
./ultimate_setup.sh
```

That's it! The script will:
1. Check your system
2. Install all packages
3. Create all configurations
4. Set up wallust with all templates
5. Install the `cwal` command
6. Configure everything automatically

### Step 2: Add Wallpapers

```bash
# Add your wallpapers to the directory
cp /path/to/your/wallpapers/* ~/Pictures/Wallpapers/

# Or download some
cd ~/Pictures/Wallpapers/
wget https://example.com/wallpaper.jpg
```

### Step 3: Start Your Session

```bash
# If using startx
startx

# If using a display manager, select bspwm at login
```

### Step 4: Set Your Wallpaper

```bash
# Random wallpaper (recommended first time)
cwal --random

# Or specific wallpaper
cwal ~/Pictures/Wallpapers/mountain.jpg

# Or just the filename
cwal mountain.jpg
```

## 💫 Using CWAL

**CWAL** (Change Wallpaper And Layout) is your simple command for everything.

### Basic Usage

```bash
# Set specific wallpaper (full path)
cwal /path/to/wallpaper.jpg

# Set wallpaper by filename (searches ~/Pictures/Wallpapers)
cwal nature.jpg

# Fuzzy search (finds *mountain* in filename)
cwal mountain

# Random wallpaper
cwal --random
cwal -r

# List all wallpapers
cwal --list
cwal -l

# Show current wallpaper
cwal --current
cwal -c

# Help
cwal --help
cwal -h
```

### What CWAL Does

When you run `cwal`, it automatically:

1. ✅ Generates color scheme from wallpaper (wallust)
2. ✅ Sets wallpaper (feh)
3. ✅ Updates bspwm border colors
4. ✅ Reloads polybar with new colors
5. ✅ Restarts dunst with new theme
6. ✅ Updates alacritty terminal colors
7. ✅ Reloads tmux with new status bar
8. ✅ Updates yazi file manager theme
9. ✅ Updates neovim colorscheme
10. ✅ Clears rofi cache
11. ✅ Sends notification

**Everything updates instantly!** 🎨

### Examples

```bash
# Morning routine - fresh random wallpaper
cwal --random

# Work mode - specific minimal wallpaper
cwal ~/Pictures/Wallpapers/minimal-desk.jpg

# Just the name works too
cwal minimal-desk.jpg

# Fuzzy search
cwal desk

# Browse and select
# Use the rofi selector (Super + W) or:
wallpaper_selector
```

## ⌨️ Keybinds

### Applications
- `Super + Enter` - Terminal (alacritty)
- `Super + D` - App launcher (rofi)
- `Super + B` - Browser (firefox)
- `Super + E` - File manager (thunar)
- `Super + Shift + E` - Yazi (TUI file manager)
- `Super + N` - Neovim

### Window Management
- `Super + Q` - Close window
- `Super + Shift + Q` - Kill window
- `Super + F` - Fullscreen
- `Super + Shift + Space` - Toggle floating
- `Super + M` - Monocle layout

### Navigation
- `Super + H/J/K/L` - Focus window (vim-like)
- `Super + Shift + H/J/K/L` - Move window
- `Super + 1-6` - Switch workspace
- `Super + Shift + 1-6` - Send to workspace
- `Super + Tab` - Window switcher (rofi)

### Wallpaper Management
- `Super + W` - Wallpaper selector (list)
- `Super + Shift + W` - Wallpaper selector (preview)
- `Super + Ctrl + W` - Random wallpaper

### System
- `Super + X` - Lock screen
- `Super + Shift + P` - Power menu
- `Super + Shift + R` - Restart bspwm
- `Super + Escape` - Reload sxhkd

### Screenshots
- `Print` - Full screenshot
- `Super + Print` - Selection screenshot

## 🎨 How Color Theming Works

```
                    Your Wallpaper
                          ↓
                   cwal wallpaper.jpg
                          ↓
              wallust analyzes colors
                          ↓
            Generates 16-color palette
                          ↓
        Creates config files for all apps:
                          ↓
    ┌────────────────────┴────────────────────┐
    │                                         │
    ├─ bspwm borders                          │
    ├─ polybar status bar                     │
    ├─ rofi app launcher                      │
    ├─ dunst notifications                    │
    ├─ alacritty terminal                     │
    ├─ tmux status line                       │
    ├─ yazi file manager                      │
    └─ neovim colorscheme                     │
                          ↓
         Everything reloads automatically
                          ↓
            Your entire desktop matches!
```

## 📁 File Structure

After installation:

```
~/.config/
├── bspwm/
│   ├── bspwmrc              # Main config
│   └── colors.sh            # Generated colors
│
├── sxhkd/
│   └── sxhkdrc              # Keybinds
│
├── polybar/
│   ├── config.ini           # Bar config
│   ├── colors.ini           # Generated colors
│   └── launch.sh            # Launch script
│
├── picom/
│   └── picom.conf           # Compositor
│
├── rofi/
│   ├── config.rasi          # Main config
│   └── colors.rasi          # Generated theme
│
├── dunst/
│   └── dunstrc              # Generated config
│
├── wallust/
│   ├── wallust.toml         # Main config
│   ├── colors.sh            # Generated colors
│   └── templates/           # All templates
│       ├── colors.sh
│       ├── colors-bspwm.sh
│       ├── colors-polybar.ini
│       ├── colors-rofi.rasi
│       ├── colors-dunst
│       ├── colors-alacritty.toml
│       ├── colors-tmux.conf
│       ├── colors-yazi.toml
│       └── colors-nvim.lua
│
├── alacritty/
│   ├── alacritty.toml       # Main config
│   └── colors.toml          # Generated colors
│
├── tmux/
│   ├── tmux.conf            # Main config
│   └── colors.conf          # Generated colors
│
├── yazi/
│   ├── yazi.toml            # Main config
│   └── theme.toml           # Generated theme
│
└── nvim/
    ├── init.lua             # Main config
    └── colors/
        └── wallust.lua      # Generated colorscheme

~/.local/bin/
├── cwal                     # Main wallpaper changer
├── wallpaper_selector       # Rofi selector
├── wallpaper_selector_preview  # Visual picker
└── wallpaper_random         # Random wallpaper

~/Pictures/
├── Wallpapers/              # Your wallpapers go here
└── Screenshots/             # Screenshots saved here
```

## 🎯 Customization

### Change Wallpaper Directory

```bash
# In your shell rc file (~/.bashrc or ~/.zshrc)
export WALLPAPER_DIR="$HOME/path/to/wallpapers"
```

### Tweak Wallust Behavior

Edit `~/.config/wallust/wallust.toml`:

```toml
# Try different backends
backend = "resized"    # Fast (default)
backend = "full"       # More accurate
backend = "kmeans"     # Alternative algorithm

# Adjust color diversity
threshold = 0.1   # More diverse colors
threshold = 0.5   # More similar colors

# Change color space
color_space = "lab"    # Default
color_space = "lch"    # Alternative
```

Then regenerate:
```bash
cwal ~/Pictures/Wallpapers/yourimage.jpg
```

### Modify What Gets Reloaded

Edit the `cwal` script in `~/.local/bin/cwal` and comment out what you don't need.

### Add More Apps to Theme

1. Create a new template in `~/.config/wallust/templates/`
2. Add it to `~/.config/wallust/wallust.toml`:
```toml
[[template]]
template = "colors-myapp.conf"
target = "~/.config/myapp/colors.conf"
```
3. Run `cwal --random` to test

## 🛠️ Troubleshooting

### CWAL command not found

```bash
# Add to PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Colors not updating

```bash
# Check if wallust is installed
which wallust

# Check if files were generated
ls ~/.config/wallust/colors.sh
ls ~/.config/polybar/colors.ini

# Manually reload everything
bspc wm -r
~/.config/polybar/launch.sh
killall dunst && dunst &
```

### Wallust fails

```bash
# Try different backend
# Edit ~/.config/wallust/wallust.toml
backend = "full"

# Or use a different image
cwal --random
```

### Polybar not showing

```bash
# Check log
tail -f /tmp/polybar.log

# Kill and restart
killall polybar
~/.config/polybar/launch.sh
```

## 💡 Tips & Tricks

### Auto-change on login

Add to `~/.config/bspwm/bspwmrc`:
```bash
cwal --random &
```

### Wallpaper slideshow

Create a cron job:
```bash
# Change every 30 minutes
*/30 * * * * DISPLAY=:0 $HOME/.local/bin/cwal --random
```

Or use systemd timer:
```bash
# ~/.config/systemd/user/wallpaper.timer
[Unit]
Description=Change wallpaper every 30 minutes

[Timer]
OnBootSec=1min
OnUnitActiveSec=30min

[Install]
WantedBy=timers.target
```

```bash
# ~/.config/systemd/user/wallpaper.service
[Unit]
Description=Random wallpaper

[Service]
Type=oneshot
ExecStart=%h/.local/bin/cwal --random
```

Enable:
```bash
systemctl --user enable --now wallpaper.timer
```

### Organize by theme

```bash
~/Pictures/Wallpapers/
├── nature/
├── space/
├── minimal/
└── dark/
```

Then:
```bash
WALLPAPER_DIR=~/Pictures/Wallpapers/nature wallpaper_selector
```

### Quick color test

```bash
# Generate without setting
wallust run /path/to/test.jpg

# Check colors
cat ~/.config/wallust/colors.sh

# If good, set it
cwal /path/to/test.jpg
```

## 📚 What Each Component Does

- **bspwm** - Manages window placement and tiling
- **sxhkd** - Handles all keyboard shortcuts
- **picom** - Adds transparency, blur, shadows, rounded corners
- **polybar** - Shows workspaces, volume, battery, time
- **rofi** - Launches apps, switches windows, selects wallpapers
- **dunst** - Shows notifications (volume, brightness, wallpaper changes)
- **wallust** - Generates color palettes from images
- **feh** - Sets wallpaper
- **alacritty** - Your terminal emulator
- **tmux** - Manage multiple terminal sessions
- **yazi** - Browse files with keyboard
- **neovim** - Text editing

## 🎉 That's It!

You now have a complete, beautiful, and fully automatic rice setup!

Just run:
```bash
cwal --random
```

And watch everything transform! 🌈

---

**Need help?** Check the log at `/tmp/bspwm_ultimate_setup_*.log`

**Want to contribute?** Feel free to customize and share!

**Enjoy your rice!** 🍚✨
