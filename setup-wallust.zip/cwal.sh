#!/bin/bash
# ============================================
# CWAL - Change Wallpaper And Layout
# ============================================
# Simple command to change wallpaper and update
# all color schemes for bspwm, polybar, rofi,
# dunst, alacritty, tmux, yazi, and neovim
# ============================================

VERSION="1.0.0"
WALLPAPER_DIR="$HOME/Pictures/Wallpapers"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# ============================================
# Helper Functions
# ============================================

print_error() {
    echo -e "${RED}✗${NC} $1" >&2
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_info() {
    echo -e "${BLUE}→${NC} $1"
}

show_help() {
    cat << EOF
${CYAN}CWAL - Change Wallpaper And Layout${NC}

${WHITE}Usage:${NC}
  cwal /path/to/wallpaper.jpg         Set specific wallpaper
  cwal wallpaper.jpg                  Search in ~/Pictures/Wallpapers
  cwal mountain                       Fuzzy search for *mountain*
  cwal --random                       Set random wallpaper
  cwal -r                             Set random wallpaper (short)
  cwal --list                         List available wallpapers
  cwal -l                             List available wallpapers (short)
  cwal --current                      Show current wallpaper
  cwal -c                             Show current wallpaper (short)
  cwal --help                         Show this help
  cwal -h                             Show this help (short)
  cwal --version                      Show version
  cwal -v                             Show version (short)

${WHITE}Examples:${NC}
  cwal ~/Downloads/nature.jpg         Absolute path
  cwal nature.jpg                     Filename in wallpaper dir
  cwal mountain                       Find any file with "mountain"
  cwal --random                       Random wallpaper

${WHITE}What it updates:${NC}
  • Wallpaper (feh)
  • bspwm borders
  • Polybar colors
  • Rofi theme
  • Dunst notifications
  • Alacritty terminal
  • Tmux status bar
  • Yazi file manager
  • Neovim colorscheme

${WHITE}Environment:${NC}
  WALLPAPER_DIR   Directory to search (default: ~/Pictures/Wallpapers)

${WHITE}Version:${NC} $VERSION
EOF
}

show_version() {
    echo "cwal version $VERSION"
}

get_current_wallpaper() {
    local fehbg="$HOME/.fehbg"
    if [ -f "$fehbg" ]; then
        grep -oP "feh.* '\K[^']+(?=')" "$fehbg" 2>/dev/null || echo "Unknown"
    else
        echo "No wallpaper set"
    fi
}

list_wallpapers() {
    if [ ! -d "$WALLPAPER_DIR" ]; then
        print_error "Wallpaper directory not found: $WALLPAPER_DIR"
        return 1
    fi
    
    local wallpapers
    wallpapers=$(find "$WALLPAPER_DIR" -maxdepth 1 -type f \( \
        -iname "*.jpg" -o -iname "*.jpeg" -o \
        -iname "*.png" -o -iname "*.webp" \
    \) 2>/dev/null | sort)
    
    if [ -z "$wallpapers" ]; then
        print_error "No wallpapers found in $WALLPAPER_DIR"
        return 1
    fi
    
    echo -e "${CYAN}Available Wallpapers:${NC}"
    echo ""
    
    local count=0
    while IFS= read -r file; do
        ((count++))
        local basename=$(basename "$file")
        local size=$(du -h "$file" | cut -f1)
        printf "  ${GREEN}%3d${NC}. %-40s ${BLUE}%s${NC}\n" "$count" "$basename" "$size"
    done <<< "$wallpapers"
    
    echo ""
    echo "Total: $count wallpapers"
}

find_wallpaper() {
    local query="$1"
    
    # Absolute path
    if [[ "$query" == /* ]] && [ -f "$query" ]; then
        echo "$query"
        return 0
    fi
    
    # Relative path
    if [ -f "$query" ]; then
        realpath "$query"
        return 0
    fi
    
    # Search in wallpaper directory
    if [ -d "$WALLPAPER_DIR" ]; then
        # Exact match
        if [ -f "$WALLPAPER_DIR/$query" ]; then
            echo "$WALLPAPER_DIR/$query"
            return 0
        fi
        
        # Case-insensitive exact match
        local found
        found=$(find "$WALLPAPER_DIR" -maxdepth 1 -type f -iname "$query" 2>/dev/null | head -n 1)
        if [ -n "$found" ]; then
            echo "$found"
            return 0
        fi
        
        # Fuzzy match
        found=$(find "$WALLPAPER_DIR" -maxdepth 1 -type f -iname "*$query*" \( \
            -iname "*.jpg" -o -iname "*.jpeg" -o \
            -iname "*.png" -o -iname "*.webp" \
        \) 2>/dev/null | head -n 1)
        
        if [ -n "$found" ]; then
            echo "$found"
            return 0
        fi
    fi
    
    return 1
}

get_random_wallpaper() {
    if [ ! -d "$WALLPAPER_DIR" ]; then
        print_error "Wallpaper directory not found: $WALLPAPER_DIR"
        return 1
    fi
    
    local random
    random=$(find "$WALLPAPER_DIR" -maxdepth 1 -type f \( \
        -iname "*.jpg" -o -iname "*.jpeg" -o \
        -iname "*.png" -o -iname "*.webp" \
    \) 2>/dev/null | shuf -n 1)
    
    if [ -z "$random" ]; then
        print_error "No wallpapers found in $WALLPAPER_DIR"
        return 1
    fi
    
    echo "$random"
}

# ============================================
# Main Wallpaper Changer
# ============================================

apply_wallpaper() {
    local wallpaper="$1"
    
    # Validate file
    if [ ! -f "$wallpaper" ]; then
        print_error "File not found: $wallpaper"
        return 1
    fi
    
    if ! file "$wallpaper" | grep -qiE "image|jpeg|png|webp"; then
        print_error "File is not a valid image: $wallpaper"
        return 1
    fi
    
    print_info "Applying wallpaper: $(basename "$wallpaper")"
    
    # Generate colors with wallust
    print_info "Generating color scheme..."
    if ! wallust run "$wallpaper" 2>/dev/null; then
        print_error "Failed to generate colors with wallust"
        print_info "Make sure wallust is installed: yay -S wallust"
        return 1
    fi
    print_success "Colors generated"
    
    # Set wallpaper
    print_info "Setting wallpaper..."
    if ! feh --bg-fill "$wallpaper" 2>/dev/null; then
        print_error "Failed to set wallpaper with feh"
        return 1
    fi
    print_success "Wallpaper set"
    
    # Reload components
    print_info "Reloading components..."
    
    # bspwm
    if command -v bspc >/dev/null 2>&1; then
        bspc wm -r 2>/dev/null && print_success "bspwm reloaded"
    fi
    
    # Polybar
    if [ -x "$HOME/.config/polybar/launch.sh" ]; then
        "$HOME/.config/polybar/launch.sh" &>/dev/null &
        print_success "Polybar reloaded"
    fi
    
    # Dunst
    if command -v dunst >/dev/null 2>&1; then
        killall dunst 2>/dev/null
        sleep 0.2
        dunst &>/dev/null &
        print_success "Dunst reloaded"
    fi
    
    # Rofi cache
    rm -f ~/.cache/rofi-*.runcache 2>/dev/null
    print_success "Rofi cache cleared"
    
    # Alacritty
    if [ -f "$HOME/.config/alacritty/alacritty.toml" ]; then
        touch "$HOME/.config/alacritty/alacritty.toml" 2>/dev/null
        print_success "Alacritty notified"
    fi
    
    # Tmux (reload for existing sessions)
    if command -v tmux >/dev/null 2>&1 && tmux ls &>/dev/null; then
        tmux source-file ~/.config/tmux/tmux.conf &>/dev/null
        print_success "Tmux reloaded"
    fi
    
    # Send notification
    if command -v notify-send >/dev/null 2>&1; then
        sleep 0.5  # Wait for dunst
        notify-send -u normal -t 3000 \
            "Wallpaper Changed" \
            "$(basename "$wallpaper")\nColors updated!" \
            2>/dev/null || true
    fi
    
    echo ""
    print_success "Wallpaper changed successfully!"
    echo -e "  ${CYAN}Image:${NC} $(basename "$wallpaper")"
    echo -e "  ${CYAN}Path:${NC}  $wallpaper"
    
    # Show color info
    if [ -f "$HOME/.config/wallust/colors.sh" ]; then
        source "$HOME/.config/wallust/colors.sh" 2>/dev/null
        echo ""
        echo -e "${CYAN}Color Scheme:${NC}"
        echo -e "  Background: ${background}"
        echo -e "  Foreground: ${foreground}"
        echo -e "  Accent:     ${color4}"
    fi
    
    return 0
}

# ============================================
# Main Logic
# ============================================

main() {
    # Handle options
    case "$1" in
        --help|-h|help)
            show_help
            exit 0
            ;;
        --version|-v|version)
            show_version
            exit 0
            ;;
        --current|-c)
            echo "Current wallpaper:"
            get_current_wallpaper
            exit 0
            ;;
        --list|-l)
            list_wallpapers
            exit 0
            ;;
        --random|-r)
            WALLPAPER=$(get_random_wallpaper)
            if [ $? -ne 0 ] || [ -z "$WALLPAPER" ]; then
                exit 1
            fi
            ;;
        "")
            print_error "No wallpaper specified"
            echo ""
            echo "Usage: cwal /path/to/wallpaper.jpg"
            echo "   or: cwal --help"
            exit 1
            ;;
        *)
            WALLPAPER=$(find_wallpaper "$1")
            if [ $? -ne 0 ] || [ -z "$WALLPAPER" ]; then
                print_error "Wallpaper not found: $1"
                echo ""
                echo "Searched in:"
                echo "  - Current directory"
                echo "  - $WALLPAPER_DIR"
                echo ""
                echo "Use 'cwal --list' to see available wallpapers"
                exit 1
            fi
            ;;
    esac
    
    # Apply the wallpaper
    apply_wallpaper "$WALLPAPER"
}

# Run
main "$@"
