#!/bin/bash
# ============================================
# ULTIMATE BSPWM + WALLUST RICE SETUP
# ============================================
# Complete automated setup for a fresh Arch system
# Installs and configures: bspwm, wallust, polybar,
# rofi, dunst, picom, alacritty, tmux, yazi, neovim
# ============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/bspwm_ultimate_setup_$(date +%Y%m%d_%H%M%S).log"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# ============================================
# Logging Functions
# ============================================

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

print_header() {
    echo ""
    echo -e "${CYAN}========================================${NC}"
    echo -e "${WHITE}$1${NC}"
    echo -e "${CYAN}========================================${NC}"
    echo ""
    log "SECTION: $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
    log "SUCCESS: $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
    log "ERROR: $1"
}

print_info() {
    echo -e "${BLUE}→${NC} $1"
    log "INFO: $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
    log "WARNING: $1"
}

print_step() {
    echo -e "${MAGENTA}▸${NC} $1"
    log "STEP: $1"
}

# ============================================
# Welcome Screen
# ============================================

show_welcome() {
    clear
    echo -e "${CYAN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║     ULTIMATE BSPWM + WALLUST RICE SETUP              ║
║                                                       ║
║     Everything Automated - Just Sit Back!            ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo -e "${WHITE}This script will install and configure:${NC}"
    echo -e "  ${GREEN}•${NC} bspwm + sxhkd (window manager)"
    echo -e "  ${GREEN}•${NC} picom (compositor with blur)"
    echo -e "  ${GREEN}•${NC} polybar (status bar)"
    echo -e "  ${GREEN}•${NC} rofi (app launcher)"
    echo -e "  ${GREEN}•${NC} dunst (notifications)"
    echo -e "  ${GREEN}•${NC} wallust (dynamic color schemes)"
    echo -e "  ${GREEN}•${NC} alacritty (terminal)"
    echo -e "  ${GREEN}•${NC} tmux (terminal multiplexer)"
    echo -e "  ${GREEN}•${NC} yazi (file manager)"
    echo -e "  ${GREEN}•${NC} neovim (text editor)"
    echo -e "  ${GREEN}•${NC} Advanced wallpaper management"
    echo ""
    
    log "=== Ultimate Setup Started ==="
    
    read -p "Press Enter to begin setup or Ctrl+C to cancel..."
}

# ============================================
# System Check
# ============================================

check_system() {
    print_header "System Check"
    
    if ! command -v pacman &> /dev/null; then
        print_error "Not an Arch-based system"
        exit 1
    fi
    print_success "Arch-based system detected"
    
    # Check for AUR helper
    if command -v yay &> /dev/null; then
        AUR_HELPER="yay"
    elif command -v paru &> /dev/null; then
        AUR_HELPER="paru"
    else
        AUR_HELPER=""
    fi
    
    if [ -n "$AUR_HELPER" ]; then
        print_success "AUR helper found: $AUR_HELPER"
    else
        print_warning "No AUR helper found (yay/paru)"
        echo "  Install yay with:"
        echo "  git clone https://aur.archlinux.org/yay.git && cd yay && makepkg -si"
    fi
    
    if ping -c 1 archlinux.org &> /dev/null; then
        print_success "Internet connection available"
    else
        print_error "No internet connection"
        exit 1
    fi
}

# ============================================
# Package Installation
# ============================================

install_packages() {
    print_header "Package Installation"
    
    local packages=(
        "bspwm" "sxhkd" "polybar" "picom" "dunst" "rofi" "feh"
        "brightnessctl" "pulseaudio" "pamixer" "scrot" "i3lock"
        "alacritty" "firefox" "thunar"
        "ttf-jetbrains-mono-nerd" "papirus-icon-theme"
        "nsxiv" "tmux" "neovim" "yazi" "ffmpegthumbnailer" "poppler"
        "xclip" "ripgrep" "fd" "libnotify"
    )
    
    local missing=()
    for pkg in "${packages[@]}"; do
        if ! pacman -Qi "$pkg" &> /dev/null; then
            missing+=("$pkg")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        print_warning "Missing ${#missing[@]} packages"
        print_info "Packages to install: ${missing[*]}"
        read -p "Install missing packages? (Y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            sudo pacman -S --needed --noconfirm "${missing[@]}"
            print_success "Packages installed"
        fi
    else
        print_success "All packages already installed"
    fi
    
    # Install wallust from AUR
    if ! command -v wallust &> /dev/null; then
        print_warning "wallust not installed"
        if [ -n "$AUR_HELPER" ]; then
            read -p "Install wallust from AUR? (Y/n) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Nn]$ ]]; then
                $AUR_HELPER -S --needed --noconfirm wallust
                print_success "wallust installed"
            fi
        else
            print_warning "No AUR helper available to install wallust"
            echo "  Install manually with: yay -S wallust"
        fi
    else
        print_success "wallust already installed"
    fi
}

# ============================================
# Create Directories
# ============================================

create_directories() {
    print_header "Creating Directories"
    
    local dirs=(
        "$HOME/.config/bspwm"
        "$HOME/.config/sxhkd"
        "$HOME/.config/polybar"
        "$HOME/.config/picom"
        "$HOME/.config/dunst"
        "$HOME/.config/rofi"
        "$HOME/.config/wallust/templates"
        "$HOME/.config/alacritty"
        "$HOME/.config/tmux"
        "$HOME/.config/yazi"
        "$HOME/.config/nvim/colors"
        "$HOME/.local/bin"
        "$HOME/Pictures/Wallpapers"
        "$HOME/Pictures/Screenshots"
    )
    
    for dir in "${dirs[@]}"; do
        mkdir -p "$dir"
    done
    
    print_success "Directories created"
}

# ============================================
# WALLUST CONFIGURATION
# ============================================

setup_wallust() {
    print_header "Setting Up Wallust"
    
    # Create wallust.toml
    cat > "$HOME/.config/wallust/wallust.toml" << 'WALLUST_EOF'
backend = "resized"
color_space = "lab"
threshold = 0.1
palette_size = 16
check_contrast = true

[[template]]
template = "colors.sh"
target = "~/.config/wallust/colors.sh"

[[template]]
template = "colors-bspwm.sh"
target = "~/.config/bspwm/colors.sh"

[[template]]
template = "colors-polybar.ini"
target = "~/.config/polybar/colors.ini"

[[template]]
template = "colors-rofi.rasi"
target = "~/.config/rofi/colors.rasi"

[[template]]
template = "colors-dunst"
target = "~/.config/dunst/dunstrc"

[[template]]
template = "colors-alacritty.toml"
target = "~/.config/alacritty/colors.toml"

[[template]]
template = "colors-tmux.conf"
target = "~/.config/tmux/colors.conf"

[[template]]
template = "colors-yazi.toml"
target = "~/.config/yazi/theme.toml"

[[template]]
template = "colors-nvim.lua"
target = "~/.config/nvim/colors/wallust.lua"
WALLUST_EOF
    
    print_success "Created wallust.toml"
    
    # Create all templates
    create_wallust_templates
}

create_wallust_templates() {
    print_step "Creating wallust templates..."
    
    # colors.sh template
    cat > "$HOME/.config/wallust/templates/colors.sh" << 'EOF'
#!/bin/sh
background='{{background}}'
foreground='{{foreground}}'
cursor='{{cursor}}'
color0='{{color0}}'
color1='{{color1}}'
color2='{{color2}}'
color3='{{color3}}'
color4='{{color4}}'
color5='{{color5}}'
color6='{{color6}}'
color7='{{color7}}'
color8='{{color8}}'
color9='{{color9}}'
color10='{{color10}}'
color11='{{color11}}'
color12='{{color12}}'
color13='{{color13}}'
color14='{{color14}}'
color15='{{color15}}'

export background foreground cursor
export color0 color1 color2 color3 color4 color5 color6 color7
export color8 color9 color10 color11 color12 color13 color14 color15
EOF

    # colors-bspwm.sh template  
    cat > "$HOME/.config/wallust/templates/colors-bspwm.sh" << 'EOF'
#!/bin/sh
background='{{background}}'
foreground='{{foreground}}'
color0='{{color0}}'
color1='{{color1}}'
color2='{{color2}}'
color3='{{color3}}'
color4='{{color4}}'
color5='{{color5}}'
color6='{{color6}}'
color7='{{color7}}'
color8='{{color8}}'
EOF

    # colors-polybar.ini template
    cat > "$HOME/.config/wallust/templates/colors-polybar.ini" << 'EOF'
[colors]
background = {{background}}
background-alt = {{color0}}
foreground = {{foreground}}
foreground-dim = {{color8}}
accent = {{color4}}
urgent = {{color1}}
EOF

    # colors-rofi.rasi template
    cat > "$HOME/.config/wallust/templates/colors-rofi.rasi" << 'EOF'
* {
    background:     {{background}};
    background-alt: {{color0}};
    foreground:     {{foreground}};
    selected:       {{color4}};
    active:         {{color2}};
    urgent:         {{color1}};
}
EOF

    # colors-dunst template
    cat > "$HOME/.config/wallust/templates/colors-dunst" << 'EOF'
[global]
    font = JetBrainsMono Nerd Font 10
    format = "<b>%s</b>\n%b"
    sort = yes
    alignment = left
    word_wrap = yes
    width = 300
    height = 300
    origin = top-right
    offset = 20x50
    transparency = 5
    frame_width = 2
    frame_color = "{{color4}}"
    corner_radius = 8
    padding = 8
    horizontal_padding = 8
    separator_color = frame

[urgency_low]
    background = "{{background}}"
    foreground = "{{foreground}}"
    timeout = 5

[urgency_normal]
    background = "{{background}}"
    foreground = "{{foreground}}"
    timeout = 10

[urgency_critical]
    background = "{{color1}}"
    foreground = "{{background}}"
    frame_color = "{{color1}}"
    timeout = 0
EOF

    # colors-alacritty.toml template
    cat > "$HOME/.config/wallust/templates/colors-alacritty.toml" << 'EOF'
[colors.primary]
background = "{{background}}"
foreground = "{{foreground}}"

[colors.cursor]
text = "{{background}}"
cursor = "{{cursor}}"

[colors.normal]
black = "{{color0}}"
red = "{{color1}}"
green = "{{color2}}"
yellow = "{{color3}}"
blue = "{{color4}}"
magenta = "{{color5}}"
cyan = "{{color6}}"
white = "{{color7}}"

[colors.bright]
black = "{{color8}}"
red = "{{color9}}"
green = "{{color10}}"
yellow = "{{color11}}"
blue = "{{color12}}"
magenta = "{{color13}}"
cyan = "{{color14}}"
white = "{{color15}}"
EOF

    # colors-tmux.conf template
    cat > "$HOME/.config/wallust/templates/colors-tmux.conf" << 'EOF'
set-option -g status-style "bg={{background}},fg={{foreground}}"
set-option -g status-left-style "bg={{color4}},fg={{background}}"
set-option -g status-right-style "bg={{color4}},fg={{background}}"
set-option -g window-status-style "bg={{background}},fg={{foreground}}"
set-option -g window-status-current-style "bg={{color4}},fg={{background}}"
set-option -g pane-border-style "fg={{color8}}"
set-option -g pane-active-border-style "fg={{color4}}"
set-option -g message-style "bg={{color4}},fg={{background}}"
set-option -g status-left " #S "
set-option -g status-right " %H:%M "
set-option -g status-justify centre
set-window-option -g window-status-format " #I: #W "
set-window-option -g window-status-current-format " #I: #W "
EOF

    # colors-yazi.toml template
    cat > "$HOME/.config/wallust/templates/colors-yazi.toml" << 'EOF'
[manager]
cwd = { fg = "{{color4}}" }
hovered = { fg = "{{background}}", bg = "{{color4}}" }
preview_hovered = { underline = true }
find_keyword = { fg = "{{color3}}", italic = true }
find_position = { fg = "{{color5}}", bg = "reset", italic = true }
marker_selected = { fg = "{{color2}}", bg = "{{color2}}" }
marker_copied = { fg = "{{color3}}", bg = "{{color3}}" }
marker_cut = { fg = "{{color1}}", bg = "{{color1}}" }
tab_active = { fg = "{{background}}", bg = "{{color4}}" }
tab_inactive = { fg = "{{foreground}}", bg = "{{background}}" }
border_style = { fg = "{{color8}}" }

[status]
separator_style = { fg = "{{color8}}", bg = "{{color8}}" }
mode_normal = { fg = "{{background}}", bg = "{{color4}}", bold = true }
mode_select = { fg = "{{background}}", bg = "{{color2}}", bold = true }
mode_unset = { fg = "{{background}}", bg = "{{color1}}", bold = true }
progress_label = { fg = "{{foreground}}", bold = true }
progress_normal = { fg = "{{color4}}", bg = "{{background}}" }
progress_error = { fg = "{{color1}}", bg = "{{background}}" }

[filetype]
rules = [
    { mime = "image/*", fg = "{{color6}}" },
    { mime = "video/*", fg = "{{color3}}" },
    { mime = "audio/*", fg = "{{color3}}" },
]
EOF

    # colors-nvim.lua template
    cat > "$HOME/.config/wallust/templates/colors-nvim.lua" << 'EOF'
vim.cmd('hi clear')
if vim.fn.exists('syntax_on') then vim.cmd('syntax reset') end
vim.o.background = 'dark'
vim.g.colors_name = 'wallust'

local c = {
    bg='{{background}}', fg='{{foreground}}',
    c0='{{color0}}', c1='{{color1}}', c2='{{color2}}', c3='{{color3}}',
    c4='{{color4}}', c5='{{color5}}', c6='{{color6}}', c7='{{color7}}',
    c8='{{color8}}', c9='{{color9}}', c10='{{color10}}', c11='{{color11}}',
    c12='{{color12}}', c13='{{color13}}', c14='{{color14}}', c15='{{color15}}',
}

local function hi(g, o)
    local cmd = 'hi ' .. g
    if o.fg then cmd = cmd .. ' guifg=' .. o.fg end
    if o.bg then cmd = cmd .. ' guibg=' .. o.bg end
    if o.gui then cmd = cmd .. ' gui=' .. o.gui end
    vim.cmd(cmd)
end

hi('Normal', {fg=c.fg, bg=c.bg})
hi('LineNr', {fg=c.c8})
hi('CursorLine', {bg=c.c0})
hi('CursorLineNr', {fg=c.c4, gui='bold'})
hi('Visual', {bg=c.c8})
hi('Search', {fg=c.bg, bg=c.c3})
hi('IncSearch', {fg=c.bg, bg=c.c4})
hi('StatusLine', {fg=c.fg, bg=c.c0})
hi('VertSplit', {fg=c.c8, bg=c.bg})
hi('Pmenu', {fg=c.fg, bg=c.c0})
hi('PmenuSel', {fg=c.bg, bg=c.c4})
hi('Comment', {fg=c.c8, gui='italic'})
hi('Constant', {fg=c.c1})
hi('String', {fg=c.c2})
hi('Number', {fg=c.c3})
hi('Function', {fg=c.c4})
hi('Statement', {fg=c.c5, gui='bold'})
hi('Operator', {fg=c.c6})
hi('Type', {fg=c.c3, gui='bold'})
hi('Error', {fg=c.c1, bg=c.bg})
hi('Todo', {fg=c.c3, bg=c.bg, gui='bold'})
hi('Directory', {fg=c.c4})
hi('Title', {fg=c.c4, gui='bold'})
EOF

    print_success "All wallust templates created"
}

# Now I'll continue with the rest of the setup script in the next part...

# ============================================
# Create Configuration Files
# ============================================

create_configs() {
    print_header "Creating Configuration Files"
    
    # bspwmrc
    print_step "Creating bspwmrc..."
    cat > "$HOME/.config/bspwm/bspwmrc" << 'BSPWMRC'
#!/bin/sh

. "${HOME}/.config/bspwm/colors.sh"

bspc config border_width         2
bspc config window_gap           12
bspc config split_ratio          0.52

bspc config normal_border_color   "$background"
bspc config active_border_color   "$color8"
bspc config focused_border_color  "$color4"
bspc config presel_feedback_color "$color1"

bspc config single_monocle        false
bspc config borderless_monocle    true
bspc config gapless_monocle       true
bspc config focus_follows_pointer true

bspc monitor -d 1 2 3 4 5 6

bspc rule -a Gimp state=floating follow=on
bspc rule -a mpv state=floating

pgrep -x sxhkd > /dev/null || sxhkd &
pgrep -x picom > /dev/null || picom --config ~/.config/picom/picom.conf &
pgrep -x dunst > /dev/null || dunst &
~/.config/polybar/launch.sh &
BSPWMRC
    chmod +x "$HOME/.config/bspwm/bspwmrc"
    
    # sxhkdrc
    print_step "Creating sxhkdrc..."
    cat > "$HOME/.config/sxhkd/sxhkdrc" << 'SXHKDRC'
super + Return
    alacritty

super + d
    rofi -show drun

super + Tab
    rofi -show window

super + b
    firefox

super + e
    thunar

super + shift + e
    alacritty -e yazi

super + n
    alacritty -e nvim

super + Escape
    pkill -USR1 -x sxhkd; notify-send 'sxhkd' 'Config reloaded'

super + shift + r
    bspc wm -r

super + {_,shift + }q
    bspc node -{c,k}

super + f
    bspc node -t ~fullscreen

super + shift + space
    bspc node -t ~floating

super + m
    bspc desktop -l next

super + {_,shift + }{h,j,k,l}
    bspc node -{f,s} {west,south,north,east}

super + {_,shift + }{1-6}
    bspc {desktop -f,node -d} '^{1-6}'

super + w
    wallpaper_selector

super + shift + w
    wallpaper_selector_preview

super + ctrl + w
    wallpaper_random

XF86AudioRaiseVolume
    pactl set-sink-volume @DEFAULT_SINK@ +5%; notify-send -t 1000 "Volume" "$(pactl get-sink-volume @DEFAULT_SINK@ | grep -Po '\d+(?=%)' | head -1)%"

XF86AudioLowerVolume
    pactl set-sink-volume @DEFAULT_SINK@ -5%; notify-send -t 1000 "Volume" "$(pactl get-sink-volume @DEFAULT_SINK@ | grep -Po '\d+(?=%)' | head -1)%"

XF86AudioMute
    pactl set-sink-mute @DEFAULT_SINK@ toggle; notify-send -t 1000 "Volume" "Toggled"

XF86MonBrightnessUp
    brightnessctl set +5%; notify-send -t 1000 "Brightness" "$(brightnessctl get)"

XF86MonBrightnessDown
    brightnessctl set 5%-; notify-send -t 1000 "Brightness" "$(brightnessctl get)"

Print
    scrot ~/Pictures/Screenshots/%Y-%m-%d_%H-%M-%S.png -e 'notify-send "Screenshot" "$f"'

super + Print
    scrot -s ~/Pictures/Screenshots/%Y-%m-%d_%H-%M-%S.png -e 'notify-send "Screenshot" "$f"'

super + x
    i3lock -c 000000

super + shift + p
    echo -e "Shutdown\nReboot\nLogout" | rofi -dmenu -p "Power" | xargs -I {} sh -c 'case {} in Shutdown) systemctl poweroff;; Reboot) systemctl reboot;; Logout) bspc quit;; esac'
SXHKDRC
    
    # picom.conf
    print_step "Creating picom.conf..."
    cat > "$HOME/.config/picom/picom.conf" << 'PICOM'
backend = "glx";
glx-no-stencil = true;
glx-copy-from-front = false;

shadow = true;
shadow-radius = 12;
shadow-offset-x = -12;
shadow-offset-y = -12;
shadow-opacity = 0.5;

fading = true;
fade-in-step = 0.03;
fade-out-step = 0.03;
fade-delta = 5;

inactive-opacity = 0.95;
frame-opacity = 1.0;
inactive-opacity-override = false;

blur-method = "dual_kawase";
blur-strength = 6;
blur-background = true;
blur-background-frame = true;

corner-radius = 12;

vsync = true;
mark-wmwin-focused = true;
mark-ovredir-focused = true;
detect-rounded-corners = true;
detect-client-opacity = true;
detect-transient = true;
use-damage = true;
PICOM
    
    # polybar config.ini
    print_step "Creating polybar config..."
    cat > "$HOME/.config/polybar/config.ini" << 'POLYBAR'
[colors]
include-file = ~/.config/polybar/colors.ini

[bar/main]
width = 30%
height = 32
offset-x = 35%
offset-y = 10
radius = 16
fixed-center = true

background = ${colors.background}
foreground = ${colors.foreground}

padding-left = 2
padding-right = 2
module-margin = 0

separator = " "
separator-foreground = ${colors.foreground-dim}

font-0 = JetBrainsMono Nerd Font:size=10;3
font-1 = JetBrainsMono Nerd Font:size=12;3

modules-left = left bspwm right
modules-right = left2 pulseaudio sep battery sep network sep date right2

override-redirect = false
wm-restack = bspwm

[module/left]
type = custom/text
content = "["
content-foreground = ${colors.accent}

[module/right]
type = custom/text
content = "]"
content-foreground = ${colors.accent}

[module/left2]
type = custom/text
content = "["
content-foreground = ${colors.accent}

[module/right2]
type = custom/text
content = "]"
content-foreground = ${colors.accent}

[module/sep]
type = custom/text
content = "|"
content-foreground = ${colors.foreground-dim}
content-padding = 1

[module/bspwm]
type = internal/bspwm
label-focused = %name%
label-focused-background = ${colors.accent}
label-focused-foreground = ${colors.background}
label-focused-padding = 1
label-focused-margin = 1
label-occupied = %name%
label-occupied-foreground = ${colors.foreground}
label-occupied-padding = 1
label-empty = %name%
label-empty-foreground = ${colors.foreground-dim}
label-empty-padding = 1

[module/date]
type = internal/date
interval = 1
date = %H:%M
date-alt = %a %d %b
format-prefix = " "
format-prefix-foreground = ${colors.accent}
label = %date%

[module/pulseaudio]
type = internal/pulseaudio
format-volume = <ramp-volume> <label-volume>
label-volume = %percentage%%
ramp-volume-0 = 奄
ramp-volume-1 = 奔
ramp-volume-2 = 墳
ramp-volume-foreground = ${colors.accent}

[module/battery]
type = internal/battery
battery = BAT0
adapter = AC
format-charging = <animation-charging> <label-charging>
format-discharging = <ramp-capacity> <label-discharging>
ramp-capacity-0 = 
ramp-capacity-1 = 
ramp-capacity-2 = 
ramp-capacity-3 = 
ramp-capacity-4 = 
ramp-capacity-foreground = ${colors.accent}
animation-charging-0 = 
animation-charging-1 = 
animation-charging-2 = 
animation-charging-3 = 
animation-charging-4 = 
animation-charging-foreground = ${colors.accent}

[module/network]
type = internal/network
interface = wlan0
format-connected = <label-connected>
format-disconnected = <label-disconnected>
label-connected = 直 %essid%
label-disconnected = 睊 Offline
label-disconnected-foreground = ${colors.urgent}
POLYBAR
    
    # polybar launch.sh
    print_step "Creating polybar launch script..."
    cat > "$HOME/.config/polybar/launch.sh" << 'POLYLAUNCH'
#!/bin/bash
killall -q polybar
while pgrep -u $UID -x polybar >/dev/null; do sleep 1; done
polybar main 2>&1 | tee -a /tmp/polybar.log & disown
POLYLAUNCH
    chmod +x "$HOME/.config/polybar/launch.sh"
    
    # rofi config.rasi
    print_step "Creating rofi config..."
    cat > "$HOME/.config/rofi/config.rasi" << 'ROFI'
@import "~/.config/rofi/colors.rasi"

configuration {
    modi: "drun,window,run";
    show-icons: true;
    display-drun: "󰣆 Apps";
    display-window: " Windows";
    display-run: " Run";
}

window {
    width: 600px;
    transparency: "real";
    background-color: @background;
    border: 2px;
    border-color: @selected;
    border-radius: 12px;
}

mainbox {
    background-color: transparent;
    children: [ inputbar, listview ];
    padding: 12px;
}

inputbar {
    background-color: @background-alt;
    text-color: @foreground;
    border-radius: 8px;
    padding: 8px 12px;
    children: [ prompt, entry ];
}

prompt {
    text-color: @selected;
    margin: 0 8px 0 0;
}

entry {
    placeholder: "Search...";
    text-color: @foreground;
}

listview {
    lines: 8;
    padding: 8px 0 0 0;
    scrollbar: false;
}

element {
    padding: 8px 12px;
    border-radius: 8px;
}

element selected {
    background-color: @selected;
    text-color: @background;
}

element-icon {
    size: 24px;
    margin: 0 8px 0 0;
}
ROFI
    
    # alacritty.toml
    print_step "Creating alacritty config..."
    cat > "$HOME/.config/alacritty/alacritty.toml" << 'ALACRITTY'
import = ["~/.config/alacritty/colors.toml"]

[window]
opacity = 0.95
padding = { x = 10, y = 10 }

[font]
size = 11

[font.normal]
family = "JetBrainsMono Nerd Font"
style = "Regular"

[cursor]
style = "Block"
unfocused_hollow = true
ALACRITTY
    
    # tmux.conf
    print_step "Creating tmux config..."
    cat > "$HOME/.config/tmux/tmux.conf" << 'TMUX'
unbind C-b
set-option -g prefix C-a
bind-key C-a send-prefix

set -g mouse on
set -g base-index 1
setw -g pane-base-index 1

bind | split-window -h
bind - split-window -v

bind h select-pane -L
bind j select-pane -D
bind k select-pane -U
bind l select-pane -R

bind r source-file ~/.config/tmux/tmux.conf \; display "Config reloaded!"

set-option -g allow-rename off
set -g default-terminal "screen-256color"
set-option -g status-position top

source-file ~/.config/tmux/colors.conf
TMUX
    
    # yazi.toml
    print_step "Creating yazi config..."
    cat > "$HOME/.config/yazi/yazi.toml" << 'YAZI'
[manager]
ratio = [1, 4, 3]
sort_by = "natural"
sort_dir_first = true
show_hidden = false

[opener]
edit = [{ run = 'nvim "$@"', block = true }]
open = [{ run = 'xdg-open "$@"', desc = "Open", for = "linux" }]
YAZI
    
    # neovim init.lua
    print_step "Creating neovim config..."
    cat > "$HOME/.config/nvim/init.lua" << 'NVIM'
vim.opt.number = true
vim.opt.relativenumber = true
vim.opt.mouse = 'a'
vim.opt.clipboard = 'unnamedplus'
vim.opt.ignorecase = true
vim.opt.smartcase = true
vim.opt.hlsearch = true
vim.opt.expandtab = true
vim.opt.tabstop = 4
vim.opt.shiftwidth = 4
vim.opt.smartindent = true
vim.opt.wrap = false
vim.opt.cursorline = true
vim.opt.termguicolors = true
vim.opt.signcolumn = 'yes'
vim.opt.updatetime = 300
vim.opt.scrolloff = 8
vim.opt.splitright = true
vim.opt.splitbelow = true
vim.opt.swapfile = false
vim.opt.undofile = true

vim.g.mapleader = ' '

local k = vim.keymap.set
local o = { noremap = true, silent = true }

k('n', '<C-h>', '<C-w>h', o)
k('n', '<C-j>', '<C-w>j', o)
k('n', '<C-k>', '<C-w>k', o)
k('n', '<C-l>', '<C-w>l', o)
k('n', '<Tab>', ':bnext<CR>', o)
k('n', '<S-Tab>', ':bprevious<CR>', o)
k('n', '<leader>x', ':bdelete<CR>', o)
k('v', '<', '<gv', o)
k('v', '>', '>gv', o)
k('v', 'J', ":m '>+1<CR>gv=gv", o)
k('v', 'K', ":m '<-2<CR>gv=gv", o)
k('n', '<leader>h', ':nohlsearch<CR>', o)
k('n', '<leader>w', ':w<CR>', o)
k('n', '<leader>q', ':q<CR>', o)
k('n', '<leader>e', ':Explore<CR>', o)
k('n', '<leader>v', ':vsplit<CR>', o)
k('n', '<leader>s', ':split<CR>', o)
k('n', '<leader>t', ':terminal<CR>', o)
k('t', '<Esc>', '<C-\\><C-n>', o)

pcall(function() vim.cmd('colorscheme wallust') end)

vim.g.netrw_banner = 0
vim.g.netrw_liststyle = 3
NVIM
    
    print_success "All config files created"
}

# ============================================
# Create Wallpaper Management Scripts
# ============================================

create_wallpaper_scripts() {
    print_header "Creating Wallpaper Scripts"
    
    # cwal - main wallpaper changer
    print_step "Creating cwal command..."
    cat > "$HOME/.local/bin/cwal" << 'CWAL'
#!/bin/bash
WALLPAPER="$1"
WALLPAPER_DIR="$HOME/Pictures/Wallpapers"

if [ "$WALLPAPER" = "--random" ] || [ "$WALLPAPER" = "-r" ]; then
    WALLPAPER=$(find "$WALLPAPER_DIR" -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.webp" \) 2>/dev/null | shuf -n 1)
fi

if [ -z "$WALLPAPER" ]; then
    echo "Usage: cwal /path/to/wallpaper.jpg"
    echo "   or: cwal wallpaper.jpg (searches in ~/Pictures/Wallpapers)"
    echo "   or: cwal --random"
    exit 1
fi

# Find wallpaper if only filename given
if [ ! -f "$WALLPAPER" ] && [ -f "$WALLPAPER_DIR/$WALLPAPER" ]; then
    WALLPAPER="$WALLPAPER_DIR/$WALLPAPER"
elif [ ! -f "$WALLPAPER" ]; then
    FOUND=$(find "$WALLPAPER_DIR" -type f -iname "*$WALLPAPER*" 2>/dev/null | head -n 1)
    [ -n "$FOUND" ] && WALLPAPER="$FOUND"
fi

if [ ! -f "$WALLPAPER" ]; then
    echo "Error: Wallpaper not found: $WALLPAPER"
    exit 1
fi

echo "Setting wallpaper: $(basename "$WALLPAPER")"

wallust run "$WALLPAPER" 2>/dev/null || { echo "Error: wallust failed"; exit 1; }
feh --bg-fill "$WALLPAPER" 2>/dev/null || { echo "Error: feh failed"; exit 1; }

bspc wm -r 2>/dev/null
[ -x "$HOME/.config/polybar/launch.sh" ] && "$HOME/.config/polybar/launch.sh" &>/dev/null &
killall dunst 2>/dev/null; dunst &>/dev/null &
rm -f ~/.cache/rofi-*.runcache 2>/dev/null
[ -f "$HOME/.config/alacritty/alacritty.toml" ] && touch "$HOME/.config/alacritty/alacritty.toml"

notify-send "Wallpaper Changed" "$(basename "$WALLPAPER")" -t 2000 2>/dev/null || true

echo "✓ Wallpaper and colors updated!"
CWAL
    chmod +x "$HOME/.local/bin/cwal"
    
    # wallpaper_selector
    print_step "Creating wallpaper_selector..."
    cat > "$HOME/.local/bin/wallpaper_selector" << 'SELECTOR'
#!/bin/bash
WALLPAPER_DIR="$HOME/Pictures/Wallpapers"
cd "$WALLPAPER_DIR" 2>/dev/null || { notify-send "Error" "Wallpaper directory not found"; exit 1; }
wallpapers=$(find . -maxdepth 1 -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.webp" \) -printf "%f\n" | sort)
[ -z "$wallpapers" ] && { notify-send "Error" "No wallpapers found"; exit 1; }
selected=$(echo "🎲 Random
$wallpapers" | rofi -dmenu -i -p "󰸉 Wallpaper")
[ -z "$selected" ] && exit 0
[ "$selected" = "🎲 Random" ] && exec cwal --random
cwal "$WALLPAPER_DIR/$selected"
SELECTOR
    chmod +x "$HOME/.local/bin/wallpaper_selector"
    
    # wallpaper_selector_preview
    print_step "Creating wallpaper_selector_preview..."
    cat > "$HOME/.local/bin/wallpaper_selector_preview" << 'PREVIEW'
#!/bin/bash
WALLPAPER_DIR="$HOME/Pictures/Wallpapers"
VIEWER="nsxiv"
command -v nsxiv &> /dev/null || VIEWER="sxiv"
command -v $VIEWER &> /dev/null || { notify-send "Error" "nsxiv/sxiv not installed"; exec wallpaper_selector; exit 1; }
images=$(find "$WALLPAPER_DIR" -maxdepth 1 -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.webp" \) 2>/dev/null)
[ -z "$images" ] && { notify-send "Error" "No wallpapers found"; exit 1; }
selected=$(echo "$images" | $VIEWER -t -o 2>/dev/null)
[ -n "$selected" ] && cwal "$selected"
PREVIEW
    chmod +x "$HOME/.local/bin/wallpaper_selector_preview"
    
    # wallpaper_random
    print_step "Creating wallpaper_random..."
    cat > "$HOME/.local/bin/wallpaper_random" << 'RANDOM'
#!/bin/bash
exec cwal --random
RANDOM
    chmod +x "$HOME/.local/bin/wallpaper_random"
    
    print_success "Wallpaper scripts created"
}

# ============================================
# Setup PATH
# ============================================

configure_path() {
    print_header "Configuring PATH"
    
    local shell_rc=""
    if [ -n "$BASH_VERSION" ]; then
        shell_rc="$HOME/.bashrc"
    elif [ -n "$ZSH_VERSION" ]; then
        shell_rc="$HOME/.zshrc"
    fi
    
    if [ -n "$shell_rc" ]; then
        if ! grep -q 'PATH.*\.local/bin' "$shell_rc" 2>/dev/null; then
            echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$shell_rc"
            print_success "Added ~/.local/bin to PATH in $shell_rc"
        else
            print_success "PATH already configured"
        fi
    fi
}

# ============================================
# Setup Permissions
# ============================================

setup_permissions() {
    print_header "Setting Up Permissions"
    
    if ! groups | grep -q video; then
        print_warning "User not in video group"
        read -p "Add user to video group (for brightnessctl)? (Y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            sudo usermod -aG video "$USER"
            print_success "Added to video group (logout required)"
        fi
    else
        print_success "User already in video group"
    fi
}

# ============================================
# Setup Wallpapers
# ============================================

setup_wallpapers() {
    print_header "Wallpaper Setup"
    
    local wallpaper_dir="$HOME/Pictures/Wallpapers"
    local count=$(find "$wallpaper_dir" -maxdepth 1 -type f \( -iname "*.jpg" -o -iname "*.png" \) 2>/dev/null | wc -l)
    
    if [ "$count" -eq 0 ]; then
        print_warning "No wallpapers found in $wallpaper_dir"
        print_info "Add wallpapers there and run: cwal --random"
    else
        print_success "Found $count wallpaper(s)"
        read -p "Set random wallpaper now? (Y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            if command -v wallust &> /dev/null; then
                cwal --random
                print_success "Wallpaper set!"
            fi
        fi
    fi
}

# ============================================
# Setup .xinitrc
# ============================================

setup_xinitrc() {
    print_header "Setting Up .xinitrc"
    
    if [ ! -f "$HOME/.xinitrc" ]; then
        cat > "$HOME/.xinitrc" << 'XINITRC'
#!/bin/sh
[ -f "$HOME/.Xresources" ] && xrdb -merge "$HOME/.Xresources"
exec bspwm
XINITRC
        chmod +x "$HOME/.xinitrc"
        print_success "Created .xinitrc"
    else
        if ! grep -q "exec bspwm" "$HOME/.xinitrc"; then
            print_warning ".xinitrc exists but doesn't start bspwm"
        else
            print_success ".xinitrc already configured"
        fi
    fi
}

# ============================================
# Final Summary
# ============================================

show_summary() {
    print_header "Setup Complete!"
    
    echo -e "${GREEN}"
    cat << "EOF"
    ╔═══════════════════════════════════════════╗
    ║  ✓ Installation Successful!               ║
    ╚═══════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo -e "${WHITE}Installed Components:${NC}"
    echo -e "  ${GREEN}✓${NC} bspwm + sxhkd"
    echo -e "  ${GREEN}✓${NC} picom (compositor)"
    echo -e "  ${GREEN}✓${NC} polybar (status bar)"
    echo -e "  ${GREEN}✓${NC} rofi (launcher)"
    echo -e "  ${GREEN}✓${NC} dunst (notifications)"
    echo -e "  ${GREEN}✓${NC} wallust (color schemes)"
    echo -e "  ${GREEN}✓${NC} alacritty (terminal)"
    echo -e "  ${GREEN}✓${NC} tmux (multiplexer)"
    echo -e "  ${GREEN}✓${NC} yazi (file manager)"
    echo -e "  ${GREEN}✓${NC} neovim (editor)"
    echo ""
    echo -e "${CYAN}Quick Commands:${NC}"
    echo -e "  ${WHITE}cwal /path/to/wallpaper.jpg${NC}  Change wallpaper"
    echo -e "  ${WHITE}cwal --random${NC}                 Random wallpaper"
    echo -e "  ${WHITE}wallpaper_selector${NC}            Rofi selector"
    echo ""
    echo -e "${CYAN}Keybinds:${NC}"
    echo -e "  ${BLUE}Super + Enter${NC}       Terminal"
    echo -e "  ${BLUE}Super + D${NC}           App launcher"
    echo -e "  ${BLUE}Super + W${NC}           Change wallpaper"
    echo -e "  ${BLUE}Super + Shift + W${NC}   Wallpaper preview"
    echo -e "  ${BLUE}Super + Ctrl + W${NC}    Random wallpaper"
    echo ""
    echo -e "${CYAN}Next Steps:${NC}"
    echo -e "  ${YELLOW}1.${NC} Add wallpapers to ~/Pictures/Wallpapers/"
    echo -e "  ${YELLOW}2.${NC} Logout/login (if added to video group)"
    echo -e "  ${YELLOW}3.${NC} Run: ${WHITE}startx${NC}"
    echo -e "  ${YELLOW}4.${NC} Set wallpaper: ${WHITE}cwal --random${NC}"
    echo ""
    echo -e "${WHITE}Log saved to:${NC} $LOG_FILE"
    echo ""
}

# ============================================
# Main Execution
# ============================================

main() {
    show_welcome
    check_system
    install_packages
    create_directories
    setup_wallust
    create_configs
    create_wallpaper_scripts
    configure_path
    setup_permissions
    setup_wallpapers
    setup_xinitrc
    show_summary
}

main
exit 0
