# 🎨 Ultimate BSPWM + Pywal16 Rice Setup

**Complete automated setup for Arch Linux with 16-color dynamic themes using pywal**

A one-script solution that installs and configures everything you need for a beautiful, fully themed bspwm environment with pywal's powerful 16-color generation!

## 📦 What's Different? (Pywal vs Wallust)

### Pywal16
- **16 colors** generated from wallpaper
- Python-based (pip install)
- More established, larger community
- Template system similar to wallust
- Slightly different color generation algorithm
- Better for those who want 16-color palettes

### This Setup Uses
- **pywal16** - The 16-color variant of pywal
- Same features as wallust version
- Compatible with all pywal themes and tools
- Drop-in replacement for standard pywal

## 🚀 Quick Start

### Step 1: Download and Run

```bash
# Download the pywal setup script
chmod +x ultimate_setup_pywal.sh

# Run it!
./ultimate_setup_pywal.sh
```

The script automatically:
1. Installs pywal16 via pip
2. Creates all pywal templates
3. Configures all apps
4. Sets up the `cwal` command
5. Everything ready to go!

### Step 2: Add Wallpapers

```bash
cp /path/to/your/wallpapers/* ~/Pictures/Wallpapers/
```

### Step 3: Start Your Session

```bash
startx
```

### Step 4: Set Your Wallpaper

```bash
# Random wallpaper
cwal --random

# Or specific
cwal mountain.jpg
```

## 💫 Using CWAL (Pywal Edition)

### Basic Usage

```bash
# Set wallpaper (generates 16-color palette)
cwal /path/to/wallpaper.jpg

# Random wallpaper
cwal --random
cwal -r

# List wallpapers
cwal --list
cwal -l

# Show current color palette
cwal --colors

# Show current wallpaper
cwal --current
cwal -c
```

### What CWAL Does (Pywal)

When you run `cwal`:

1. ✅ Runs pywal to generate 16-color palette
2. ✅ Sets wallpaper (feh)
3. ✅ Updates bspwm borders
4. ✅ Reloads polybar
5. ✅ Restarts dunst
6. ✅ Updates alacritty
7. ✅ Reloads tmux
8. ✅ Updates yazi theme
9. ✅ Updates neovim colors
10. ✅ Sends notification

**Everything themed with 16 colors!** 🎨

## 🎨 Pywal Color Generation

```
                 Your Wallpaper
                       ↓
              cwal wallpaper.jpg
                       ↓
          pywal analyzes the image
                       ↓
      Generates 16-color palette:
      • color0-7  (normal colors)
      • color8-15 (bright colors)
                       ↓
        Creates template files:
                       ↓
    ~/.cache/wal/colors-*.{sh,ini,rasi,conf,toml,vim}
                       ↓
         All apps reload automatically
                       ↓
            Full 16-color theme!
```

## 📁 File Structure (Pywal)

```
~/.cache/wal/                    # Pywal cache directory
├── colors                       # Plain color list
├── colors.sh                    # Shell variables
├── colors-bspwm.sh             # Generated from template
├── colors-polybar.ini          # Generated from template
├── colors-rofi.rasi            # Generated from template
├── colors-alacritty.toml       # Generated from template
├── colors-tmux.conf            # Generated from template
├── colors-yazi.toml            # Generated from template
└── colors-nvim.vim             # Generated from template

~/.config/wal/templates/         # Your templates
├── colors-bspwm.sh
├── colors-polybar.ini
├── colors-rofi.rasi
├── dunstrc
├── colors-alacritty.toml
├── colors-tmux.conf
├── colors-yazi.toml
└── colors-nvim.vim

~/.local/bin/
├── cwal                         # Wallpaper changer
├── wallpaper_selector
├── wallpaper_selector_preview
└── wallpaper_random
```

## ⌨️ Keybinds

Same as wallust version:

- `Super + Enter` - Terminal
- `Super + D` - App launcher
- `Super + W` - Wallpaper selector
- `Super + Shift + W` - Preview selector
- `Super + Ctrl + W` - Random wallpaper

Full keybind list in main setup!

## 🎯 Customization

### Adjust Pywal Generation

You can customize pywal behavior by editing the `cwal` script:

```bash
# In ~/.local/bin/cwal, find this line:
wal -i "$WALLPAPER" --saturate 0.5 -n -q

# Options:
--saturate 0.5     # Color saturation (0.0-1.0)
-n                 # Skip setting wallpaper (we use feh)
-q                 # Quiet mode
--backend wal      # Color generation backend
--backend colorz   # Alternative backend
--backend colorthief # Another backend
```

### Try Different Backends

```bash
# Edit cwal and try:
wal -i "$WALLPAPER" --backend colorz -n -q
wal -i "$WALLPAPER" --backend colorthief -n -q
wal -i "$WALLPAPER" --backend haishoku -n -q
```

Each backend generates colors differently!

### Export Pywal Themes

```bash
# Export current theme
wal -e

# This creates:
~/.cache/wal/colors.json    # Export format
```

## 🔄 Persistence

Everything persists across reboots:

1. **Config files** - All in `~/.config/`
2. **Pywal cache** - `~/.cache/wal/` persists
3. **Wallpaper** - Restored via `~/.fehbg`
4. **Colors** - Loaded on bspwm startup

On login:
- bspwm sources `~/.cache/wal/colors-bspwm.sh`
- Polybar loads `~/.cache/wal/colors-polybar.ini`
- All apps read their generated configs
- Last wallpaper is restored

## 🆚 Wallust vs Pywal - Which to Choose?

### Use Pywal16 If:
- ✅ You want 16-color palettes (full spectrum)
- ✅ You prefer Python ecosystem
- ✅ You want established, mature tool
- ✅ You use other pywal-compatible tools
- ✅ You like multiple backend options

### Use Wallust If:
- ✅ You want more control over color generation
- ✅ You prefer Rust-based tools (faster)
- ✅ You want newer, more active development
- ✅ You prefer simpler configuration
- ✅ You like the specific wallust algorithm

**Both are excellent!** This setup script supports both.

## 💡 Tips & Tricks

### See Your Color Palette

```bash
# Show all 16 colors
cwal --colors
```

### Pywal with Different Saturations

```bash
# More vibrant
wal -i ~/wallpaper.jpg --saturate 0.8 -n

# More muted
wal -i ~/wallpaper.jpg --saturate 0.3 -n
```

### Use Pywal Theme Collections

Pywal has many pre-made themes:

```bash
# Install pywal themes
git clone https://github.com/dylanaraps/pywal.git
cd pywal/colors

# Apply a theme
wal --theme base16-oceanicnext
```

### Export for Other Tools

```bash
# Export current colors to JSON
wal -e

# Use in other scripts
cat ~/.cache/wal/colors.json
```

### Pywal + Spicetify (Spotify)

```bash
# Install spicetify
yay -S spicetify-cli

# Install pywal theme
git clone https://github.com/morpheusthewhite/spicetify-themes.git
cd spicetify-themes/Pywal

# Apply
spicetify config current_theme Pywal
spicetify apply
```

Now Spotify matches too!

## 🛠️ Troubleshooting

### Pywal not found

```bash
# Install pywal16
pip install --break-system-packages pywal16

# Or standard pywal
pip install --break-system-packages pywal
```

### Colors look weird

Try different backends:
```bash
# In cwal script, change to:
wal -i "$WALLPAPER" --backend colorz -n -q
```

### Want 8 colors instead of 16?

Use standard pywal instead of pywal16:
```bash
pip uninstall pywal16
pip install --break-system-packages pywal
```

Templates will still work!

## 📚 Pywal Resources

- **Pywal16 GitHub**: https://github.com/eylles/pywal16
- **Original Pywal**: https://github.com/dylanaraps/pywal
- **Pywal Wiki**: https://github.com/dylanaraps/pywal/wiki
- **Community Themes**: https://github.com/dylanaraps/pywal/wiki/User-Themes

## 🎉 That's It!

You now have a complete bspwm rice with pywal's powerful 16-color theming!

```bash
# Set your first wallpaper
cwal --random

# Watch everything transform with 16 colors!
```

Enjoy your pywal-powered rice! 🌈✨

---

**Comparing both versions?** Both `ultimate_setup.sh` (wallust) and `ultimate_setup_pywal.sh` (pywal) are production-ready. Choose whichever color generation style you prefer!
